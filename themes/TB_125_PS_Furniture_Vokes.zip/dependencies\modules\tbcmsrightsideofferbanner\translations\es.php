<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tbcmsrightsideofferbanner}prestashop>tbcmsrightsideofferbanner_ae01fad2fade094df5bcae844e15c0a4'] = 'TemplateBeta - Una pancarta';
$_MODULE['<{tbcmsrightsideofferbanner}prestashop>tbcmsrightsideofferbanner_36ff97edbc230b2447d7504951e31469'] = 'Esto es Mostrar una pancarta en el anverso';
$_MODULE['<{tbcmsrightsideofferbanner}prestashop>tbcmsrightsideofferbanner_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuraciones';
$_MODULE['<{tbcmsrightsideofferbanner}prestashop>tbcmsrightsideofferbanner_be53a0541a6d36f6ecb879fa2c584b08'] = 'Imagen';
$_MODULE['<{tbcmsrightsideofferbanner}prestashop>tbcmsrightsideofferbanner_4c6ace7405819bffddf7ee5133db4201'] = 'Captura de imagen';
$_MODULE['<{tbcmsrightsideofferbanner}prestashop>tbcmsrightsideofferbanner_5dbade8dd1e626afef1bb69bacfd5d3a'] = 'Ingrese la leyenda de la imagen';
$_MODULE['<{tbcmsrightsideofferbanner}prestashop>tbcmsrightsideofferbanner_97e7c9a7d06eac006a28bf05467fcc8b'] = 'Enlazar';
$_MODULE['<{tbcmsrightsideofferbanner}prestashop>tbcmsrightsideofferbanner_13efb468804622637985c1b2c31058d1'] = 'Ingrese enlace de imagen';
$_MODULE['<{tbcmsrightsideofferbanner}prestashop>tbcmsrightsideofferbanner_c9cc8cce247e49bae79f15173ce97354'] = 'Salvar';
$_MODULE['<{tbcmsrightsideofferbanner}prestashop>form_92fbf0e5d97b8afd7e73126b52bdc4bb'] = 'Escoge un archivo';
